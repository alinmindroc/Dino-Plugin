mkdir -p /opt/dino
make all
