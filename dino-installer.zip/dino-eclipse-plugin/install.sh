mkdir -p /tmp/dino
make all
