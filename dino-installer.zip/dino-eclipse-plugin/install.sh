read -p "Enter directory where to put the executable parsers: " path

mkdir -p $path

if [ $? -eq 0 ]
then
	echo Installing in $path ...
	make_arg=$path"/"
	make ARGS=$make_arg all
fi
